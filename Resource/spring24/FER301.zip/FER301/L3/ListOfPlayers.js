export const Players =[
    {id: 1, name: 'Cristiano Ronaldo', club: 'Manchester United', img:'assets/images/cr.jpg'},
    {id: 2, name: 'Kante', club: 'Chelsea', img:'assets/images/kante.jpg'},
    {id: 3, name: 'Messi', club: 'PSG', img:'assets/images/messi.jpg'},
    {id: 4, name: 'Neymar', club: 'PSG',img:'assets/images/neymar.jpg'},
    {id: 5, name: 'Kane', club: 'Tottemham',img:'assets/images/kane.jpg' },
    {id: 6, name: 'Haaland', club: 'Manchester City', img:'assets/images/haaland.jpg'}
  ];